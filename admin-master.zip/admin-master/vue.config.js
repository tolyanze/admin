module.exports = {
  publicPath: '/admin/'
}
