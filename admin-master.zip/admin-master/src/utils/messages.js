 export default {
    'logout': 'Вы вышли из системы',
    'login': 'Для начала войдите в систему'
 }